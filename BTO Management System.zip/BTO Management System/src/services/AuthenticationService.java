package services;

import models.Applicant;
import models.HDBOfficer;

import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class AuthenticationService {

    private List<Applicant> applicants;
    private List<HDBOfficer> officers;
    
    

    public AuthenticationService(List<Applicant> applicants, List<HDBOfficer> officers) {
        this.applicants = applicants;
        this.officers = officers;
    }


    public Object authenticate(String nric, String password) {
    	
    	if (isValidNRIC(nric)) {
    	
        for (Applicant applicant : applicants) {
            if (applicant.getNric().equals(nric)) {
            	if (applicant.getPassword().equals(password))
            	{
            		return applicant;
            	}
            	else
            	{
            		System.out.println("Incorrect password");
            		return null;
            	}
                
            }
        }

        // Check in officers list
        for (HDBOfficer officer : officers) {
            if (officer.getNric().equals(nric)) {
            	if (officer.getPassword().equals(password))
            	{
            		return officer;
            	}
                
            	else
            	{
            		System.out.println("Incorrect password");
            		return null;
            	}
            }
        }
    	}

        
    	else {
    		System.out.println("Invalid NRIC format");
    		return null;
    	}
    		return null;
    }
    
    public static boolean isValidNRIC(String nric) {
        // Regular expression to match NRIC starting with 'S' or 'T', followed by 7 digits, and ending with a letter
        String regex = "^[ST]\\d{7}[A-Z]$";

        // Compile the regular expression
        Pattern pattern = Pattern.compile(regex);

        // Create a matcher for the input NRIC
        Matcher matcher = pattern.matcher(nric);

        // Return true if the NRIC matches the regular expression
        return matcher.matches();
    }
}
