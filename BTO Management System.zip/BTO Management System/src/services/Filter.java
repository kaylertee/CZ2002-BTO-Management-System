package services;

import models.BTOProject;

public class Filter {
    private String location;
    private String flatType;

    public Filter() {
        // Default filter settings
        this.location = "";
        this.flatType = "";
    }

    // Getters and setters
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getFlatType() {
        return flatType;
    }

    public void setFlatType(String flatType) {
        this.flatType = flatType;
    }

    // Method to apply filters to a list of projects
    public boolean applyFilter(BTOProject project) {
        boolean locationMatches = (location.isEmpty() || project.getNeighborhood().equalsIgnoreCase(location));
        boolean flatTypeMatches = (flatType.isEmpty() || project.getType1().equalsIgnoreCase(flatType) || project.getType2().equalsIgnoreCase(flatType));
        return locationMatches && flatTypeMatches;
    }
}
