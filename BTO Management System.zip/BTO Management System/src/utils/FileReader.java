package utils;

import models.Applicant;
import models.HDBOfficer;
import models.BTOProject;
import org.apache.poi.ss.usermodel.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileReader {

    // Read Applicant List from Excel
    public static List<Applicant> readApplicantList(String filePath) throws IOException {
        List<Applicant> applicants = new ArrayList<>();
        FileInputStream file = new FileInputStream(new File(filePath));
        Workbook workbook = WorkbookFactory.create(file);
        Sheet sheet = workbook.getSheetAt(0);  // assuming the data is in the first sheet

        for (Row row : sheet) {
            // Skipping the header row
            if (row.getRowNum() == 0) {
                continue;
            }

            String name = getCellValue(row.getCell(0));
            String nric = getCellValue(row.getCell(1));
            int age = (int) getNumericCellValue(row.getCell(2));
            String maritalStatus = getCellValue(row.getCell(3));
            String password = getCellValue(row.getCell(4));

            // Create the Applicant object and add it to the list
            Applicant applicant = new Applicant(name, nric, age, maritalStatus, password);
            applicants.add(applicant);
        }

        file.close();
        return applicants;
    }

    // Read Officer List from Excel
    public static List<HDBOfficer> readOfficerList(String filePath) throws IOException {
        List<HDBOfficer> officers = new ArrayList<>();
        FileInputStream file = new FileInputStream(new File(filePath));
        Workbook workbook = WorkbookFactory.create(file);
        Sheet sheet = workbook.getSheetAt(0);  // assuming the data is in the first sheet

        for (Row row : sheet) {
            // Skipping the header row
            if (row.getRowNum() == 0) {
                continue;
            }

            String name = getCellValue(row.getCell(0));
            String nric = getCellValue(row.getCell(1));
            int age = (int) getNumericCellValue(row.getCell(2));
            String maritalStatus = getCellValue(row.getCell(3));
            String password = getCellValue(row.getCell(4));

            // Create the HDBOfficer object and add it to the list
            HDBOfficer officer = new HDBOfficer(name, nric, age, maritalStatus, password);
            officers.add(officer);
        }

        file.close();
        return officers;
    }

    // Read Project List from Excel
    public static List<BTOProject> readProjectList(String filePath) throws IOException {
        List<BTOProject> projects = new ArrayList<>();
        FileInputStream file = new FileInputStream(new File(filePath));
        Workbook workbook = WorkbookFactory.create(file);
        Sheet sheet = workbook.getSheetAt(0);  // assuming the data is in the first sheet

        for (Row row : sheet) {
            // Skipping the header row
            if (row.getRowNum() == 0) {
                continue;
            }

            String projectName = getCellValue(row.getCell(0));
            String neighborhood = getCellValue(row.getCell(1));
            String type1 = getCellValue(row.getCell(2));
            int numUnitsType1 = (int) getNumericCellValue(row.getCell(3));
            double priceType1 = getNumericCellValue(row.getCell(4));
            String type2 = getCellValue(row.getCell(5));
            int numUnitsType2 = (int) getNumericCellValue(row.getCell(6));
            double priceType2 = getNumericCellValue(row.getCell(7));
            String openingDate = getCellValue(row.getCell(8));
            String closingDate = getCellValue(row.getCell(9));
            String manager = getCellValue(row.getCell(10));
            int officerSlot = (int) getNumericCellValue(row.getCell(11));
            String officer = getCellValue(row.getCell(12));

            // Create the BTOProject object and add it to the list
            BTOProject project = new BTOProject(projectName, neighborhood, type1, numUnitsType1, priceType1,
                    type2, numUnitsType2, priceType2, openingDate, closingDate, manager, officerSlot, officer);
            projects.add(project);
        }

        file.close();
        return projects;
    }

    // Get the cell value as a string (handling both String and Numeric)
    private static String getCellValue(Cell cell) {
        if (cell == null) {
            return "";
        }
        if (cell.getCellType() == CellType.STRING) {
            return cell.getStringCellValue();
        } else if (cell.getCellType() == CellType.NUMERIC) {
            return String.valueOf(cell.getNumericCellValue());
        } else {
            return "";
        }
    }

    // Get the numeric value from a cell (handles both numeric and string cells that contain numeric values)
    private static double getNumericCellValue(Cell cell) {
        if (cell == null) {
            return 0.0;
        }
        if (cell.getCellType() == CellType.NUMERIC) {
            return cell.getNumericCellValue();
        } else if (cell.getCellType() == CellType.STRING) {
            try {
                return Double.parseDouble(cell.getStringCellValue());
            } catch (NumberFormatException e) {
                return 0.0;
            }
        } else {
            return 0.0;
        }
    }
}
