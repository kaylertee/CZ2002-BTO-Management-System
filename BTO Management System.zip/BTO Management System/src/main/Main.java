package main;

import models.Applicant;

import models.HDBOfficer;
import models.BTOProject;
import services.AuthenticationService;
import services.Filter;
import utils.FileReader;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Read data from Excel files
        List<Applicant> applicants = loadApplicants();
        List<HDBOfficer> officers = loadOfficers();
        List<BTOProject> projects = loadProjects();
        
        // Test objects
        /*
        applicants.add(new Applicant("Test Applicant single", "S1111111S" , 35, "Single" ,"1"));
        applicants.add(new Applicant("Test Applicant married", "S2222222S" , 66, "Married" ,"2"));
        officers.add(new HDBOfficer("Test Officer single", "S3333333S", 35, "Single", "3"));
        officers.add(new HDBOfficer("Test Officer married", "S4444444S", 77, "Married", "4"));
        */
        
        
        // Authentication service to handle login
        AuthenticationService authService = new AuthenticationService(applicants, officers);

        System.out.println("Welcome to the BTO Management System");
        
        boolean loggedIn = false;
        Object user = null;
        Filter userFilter = new Filter();

        
        while (true) {
            // If not logged in, perform login
            while (!loggedIn) {
                System.out.print("Enter your NRIC: ");
                String nric = scanner.nextLine();
                System.out.print("Enter your password: ");
                String password = scanner.nextLine();

                // Authenticate user (whether Applicant or HDB Officer)
                user = authService.authenticate(nric, password);

                if (user == null) {
                    System.out.println("Invalid credentials! Please try again.");
                } else {
                    loggedIn = true;
                    System.out.println("Login successful!");
                }
            }

            // After successful login, show the menu
            boolean exitMenu = showMenu(scanner, user, applicants, officers, projects, userFilter);

            // If exitMenu is true, user logged out and we should reset loggedIn to false and return to login screen
            if (exitMenu) {
                loggedIn = false;
                System.out.println("You have logged out.");
            }
        }
    }

    // Load applicants from Excel
    private static List<Applicant> loadApplicants() {
        try {
            return FileReader.readApplicantList("ApplicantList.xlsx");
        } catch (IOException e) {
            System.out.println("Error reading the Applicant List: " + e.getMessage());
            return null;
        }
    }

    // Load officers from Excel
    private static List<HDBOfficer> loadOfficers() {
        try {
            return FileReader.readOfficerList("OfficerList.xlsx");
        } catch (IOException e) {
            System.out.println("Error reading the Officer List: " + e.getMessage());
            return null;
        }
    }

    // Load projects from Excel
    private static List<BTOProject> loadProjects() {
        try {
            return FileReader.readProjectList("ProjectList.xlsx");
        } catch (IOException e) {
            System.out.println("Error reading the Project List: " + e.getMessage());
            return null;
        }
    }

    // Display the menu after successful login
    private static boolean showMenu(Scanner scanner, Object user, List<Applicant> applicants, List<HDBOfficer> officers, List<BTOProject> projects, Filter userFilter) {
    	if (user instanceof HDBOfficer) {
            HDBOfficer officer = (HDBOfficer) user;
            System.out.println("Welcome, Officer " + officer.getName());
            return showOfficerMenu(scanner, officer, applicants, officers, projects, userFilter);
        }
    	else if (user instanceof Applicant) {
            Applicant applicant = (Applicant) user;
            System.out.println("Welcome, " + applicant.getName());
            return showApplicantMenu(scanner, applicant, applicants, projects, userFilter);
        }
        return false;
    }

    // Applicant menu options
    private static boolean showApplicantMenu(Scanner scanner, Applicant applicant, List<Applicant> applicants, List<BTOProject> projects, Filter userFilter) {
            System.out.println("Select an option:");
            System.out.println("1. View Available Projects");
            System.out.println("2. Apply for a Project");
            System.out.println("3. View Application Status");
            System.out.println("4. Book Flat");
            System.out.println("5. Withdraw Application");
            System.out.println("6. Change Password");
            System.out.println("7. View Profile");
            System.out.println("8. Add Filter");
            System.out.println("0. Log Out");

            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                	viewAvailableProjects(scanner, projects, userFilter, applicant);
                    break;
                case 2:
                    applyForProject(scanner, applicant, projects);
                    break;
                case 3:
                	applicant.viewApplicationStatus(); 
                    break;
                case 4:
                   applicant.bookFlat();
                    break;
                case 5:
                    applicant.withdrawApplication();
                    break;
                case 6:
                	System.out.println("Enter new password:");
                	String newPassword = scanner.nextLine();
                    applicant.setPassword(newPassword);
                    System.out.println("Password changed:");
                    return true;
                    
                case 7:
                    applicant.viewProfile();
                    break;
                case 8:
                	setFilter(scanner, userFilter);
                    break;
                case 0:
                    System.out.println("Logging out.");
                    return true;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
            return false;
        
    }

    // Officer menu options
    private static boolean showOfficerMenu(Scanner scanner, HDBOfficer officer, List<Applicant> applicants, List<HDBOfficer> officers, List<BTOProject> projects, Filter userFilter) {

            System.out.println("Select an option:");
            System.out.println("1. View Available Projects");
            System.out.println("2. Apply for a Project");
            System.out.println("3. View Application Status");
            System.out.println("4. Book Flat");
            System.out.println("5. Withdraw Application");
            System.out.println("6. Apply to be Officer of a project");
            System.out.println("7. Change Applicants' application status");
            System.out.println("8. View details of project that you are officer of");
            System.out.println("9. Generate receipt of applicants");
            System.out.println("10. Change Password");
            System.out.println("11. View Profile");
            System.out.println("12 Set Filter");
            System.out.println("0. Log out");

            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                	viewAvailableProjects(scanner, projects, userFilter, officer);
                    break;
                case 2:
                	applyForProject2(scanner, officer, projects);
                    break;
                case 3:
                	officer.viewApplicationStatus(); 
                    break;
                case 4:
                   officer.bookFlat();
                    break;
                case 5:
                    officer.withdrawApplication();
                    break;
                case 6:
                	applyForProjectAsOfficer(scanner, officer, projects);
                    break;
                case 7:
                    officer.changeApplicationStatus(applicants, officers);
                    break;
                case 8:
                   officer.officerViewProject();
                    break;
                case 9:
                	List<Applicant> allUsers = new ArrayList<>(applicants);
                	allUsers.addAll(officers);
                   officer.generateReceipt(allUsers);
                    break;
                case 10:
                	System.out.println("Enter new password:");
                	String newPassword = scanner.nextLine();
                    officer.setPassword(newPassword);
                    System.out.println("Password changed:");
                    return true;
                case 11:
                	officer.viewProfile();
                	break;
                case 12:
                	setFilter(scanner, userFilter);
                	break;

                case 0:
                    System.out.println("Logging out.");
                    return true;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
            return false;
        }
    
    private static void setFilter(Scanner scanner, Filter userFilter) {
        System.out.println("Enter location filter (leave empty for no filter):");
        String location = scanner.nextLine();
        userFilter.setLocation(location);

        System.out.println("Enter flat type filter (leave empty for no filter):");
        String flatType = scanner.nextLine();
        userFilter.setFlatType(flatType);
    }
    

    // Show available projects to the user
    private static void viewAvailableProjects(Scanner scanner, List<BTOProject> projects, Filter userFilter, Applicant applicant) {
        if (projects == null || projects.isEmpty()) {
            System.out.println("No projects available.");
            return;
        }

        System.out.println("Available Projects:");

        for (BTOProject project : projects) {
            if (userFilter.applyFilter(project)) {
                System.out.println("Project Name: " + project.getProjectName() + ", Location: " + project.getNeighborhood());
                if ("Single".equals(applicant.getMaritalStatus()) && applicant.getAge() >= 35) {
                	System.out.println("There are " + project.getNumUnitsType1() + " 2-Room units available");
                }
                
                else if ("Married".equals(applicant.getMaritalStatus()) && applicant.getAge() >= 21) {
                	System.out.println("There are " + project.getNumUnitsType1() + " 2-Room units available and " +project.getNumUnitsType2()+" 3-Room units available");
                }
            }
        }
    }

    // Apply for a project
    private static void applyForProject(Scanner scanner, Applicant applicant, List<BTOProject> projects) {
        System.out.println("Select a project to apply for:");
        for (int i = 0; i < projects.size(); i++) {
            System.out.println(i + 1 + ". " + projects.get(i).getProjectName());
        }

        int projectChoice = scanner.nextInt() - 1;
        if (projectChoice < 0 || projectChoice >= projects.size()) {
            System.out.println("Invalid project selection.");
            return;
        }

        BTOProject selectedProject = projects.get(projectChoice);

        
        if (isEligibleToApply(applicant, selectedProject)) {
            applicant.applyForProject(selectedProject);  // Calls the method to update status and apply
        } else {
            System.out.println("You are not eligible to apply for this project.");
            return;
        }
    }
    
    private static void applyForProject2(Scanner scanner, HDBOfficer officer, List<BTOProject> projects) {
        System.out.println("Select a project to apply for:");
        for (int i = 0; i < projects.size(); i++) {
            System.out.println(i + 1 + ". " + projects.get(i).getProjectName());
        }

        int projectChoice = scanner.nextInt() - 1;
        if (projectChoice < 0 || projectChoice >= projects.size()) {
            System.out.println("Invalid project selection.");
            return;
        }

        BTOProject selectedProject = projects.get(projectChoice);
        
        if (officer.getProjectsAssigned().contains(selectedProject))
        {
        	System.out.println("You are a HDB officer for this project and are not able to apply.");
        	return;
        }

        
        if (isEligibleToApply(officer, selectedProject)) {
            officer.applyForProject(selectedProject);  // Calls the method to update status and apply
        } else {
            System.out.println("You are not eligible to apply for this project.");
            return;
        }
    }

    // Check if the applicant is eligible to apply for the project
    private static boolean isEligibleToApply(Applicant applicant, BTOProject project) {

        return true; 
    }

    private static void viewAvailableProjectsForOfficer(HDBOfficer officer, List<BTOProject> projects) {
        System.out.println("Projects Available for Assignment to Officer:");
        boolean availableProjects = false;

        for (BTOProject project : projects) {
            if (!officer.getProjectsAssigned().contains(project)) {
                System.out.println("Project Name: " + project.getProjectName());
                availableProjects = true;
            }
        }

        if (!availableProjects) {
            System.out.println("You are already an officer for all projects.");
        }
    }

    // Allow the officer to apply for a project
    private static void applyForProjectAsOfficer(Scanner scanner, HDBOfficer officer, List<BTOProject> projects) {
        System.out.println("Select a project to apply for:");

        // Display the list of projects that officer is not already assigned to
        int index = 1;
        for (BTOProject project : projects) {
            if (!officer.getProjectsAssigned().contains(project)) {
                System.out.println(index + ". " + project.getProjectName());
                index++;
            }
        }

        // Get the user's selection
        int projectChoice = scanner.nextInt() - 1;
        scanner.nextLine(); // consume newline character

        if (projectChoice < 0 || projectChoice >= projects.size() || officer.getProjectsAssigned().contains(projects.get(projectChoice))) {
            System.out.println("Invalid selection or you are already assigned to this project.");
        } else {
            BTOProject selectedProject = projects.get(projectChoice);
            boolean isAssigned = officer.officerApply(selectedProject);

            if (isAssigned) {
                System.out.println("You have been successfully assigned as an officer of " + selectedProject.getProjectName());
            } else {
                System.out.println("Failed to apply for the project.");
            }
        }
    }

}
