package models;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Applicant extends User {
	Scanner scanner = new Scanner(System.in);
    private String projectStatus;
    private List<String> enquiries;  // List to store enquiries made by the applicant
    private boolean hasAppliedForProject;
    private String typeBooked;
    private String typeApplied;
    public BTOProject appliedProject;
    public BTOProject bookedProject;
    

    public Applicant(String name, String nric, int age, String maritalStatus, String password) {
        super(name, nric, age, maritalStatus, password);
        this.projectStatus = "No applied projects";  // Default status when an applicant applies
        this.enquiries = new ArrayList<>();
        this.hasAppliedForProject = false;  // Initially, no project is applied
    }

    // Getters and Setters
    public String getProjectStatus() {
        return projectStatus;
    }
    
    public String getTypeBooked() {
    	return typeBooked;
    }
    public BTOProject getProjectApplied() {
    	return appliedProject;
    }
    
    public String getTypeApplied() {
    	return typeApplied;
    }

    public void setProjectStatus(String projectStatus) {
        this.projectStatus = projectStatus;
    }

    public boolean hasAppliedForProject() {
        return hasAppliedForProject;
    }

    public void setHasAppliedForProject(boolean hasAppliedForProject) {
        this.hasAppliedForProject = hasAppliedForProject;
    }

    public List<String> getEnquiries() {
        return enquiries;
    }
    
    public void setTypeBooked(String type) {
        this.typeBooked = type;
    }

    public void setEnquiries(List<String> enquiries) {
        this.enquiries = enquiries;
    }
    

    // Method to apply for a project
    public void applyForProject(BTOProject project) {
        // Eligibility check based on marital status and age
        if (hasAppliedForProject) {
            System.out.println("You have already applied for a project.");
            return;
        }

        if ("Single".equals(this.getMaritalStatus()) && this.getAge() >= 35) {
        	System.out.println("Singles aged 35 and above can only apply for 2-Room flats. Do you want to apply for a 2-Room flat for " + project.getProjectName()+"? There are "+ project.getNumUnitsType1()+" units available. (y/n)");
        	
        	char choice = scanner.next().charAt(0);
            scanner.nextLine();
            if(choice=='y'&&project.getNumUnitsType1()>0)
            {		
                this.projectStatus = "Pending";
                this.hasAppliedForProject = true;
                this.typeApplied = "2-Room";
                this.appliedProject = project;
                project.setNumUnitsType1(project.getNumUnitsType1()-1);
                System.out.println("Application for 2-Room flat for " + project.getProjectName() + " successful.");
                return;
                
            }
            else {
            	System.out.println("Application failed, not enough flats, or invalid input");
            	return;
            }
            
        } else if ("Married".equals(this.getMaritalStatus()) && this.getAge() >= 21) {
        	
        	System.out.println("Do you want to apply for a 2-Room or 3-Room flat for " + project.getProjectName()+"? There are "+project.getNumUnitsType1()+" 2-Room units available and " +project.getNumUnitsType2()+" 3-Room units available. (2/3)");
        	int choice = scanner.nextInt();
            scanner.nextLine();
            if(choice==2&&project.getNumUnitsType1()>0)
            {
            	this.projectStatus = "Pending";
                this.hasAppliedForProject = true;
                this.typeApplied = "2-Room";
                this.appliedProject = project;
                project.setNumUnitsType1(project.getNumUnitsType1()-1);
                System.out.println("Application for 2-Room flat for " + project.getProjectName() + " successful.");
                return;
            }
            
            else if(choice==3&&project.getNumUnitsType2()>0)
            {
            	this.projectStatus = "Pending";
                this.hasAppliedForProject = true;
                this.typeApplied = "3-Room";
                this.appliedProject = project;
                project.setNumUnitsType2(project.getNumUnitsType2()-1);
                System.out.println("Application for 3-Room flat for " + project.getProjectName() + " successful.");
                return;
            }
            else
            {
            	System.out.println("Application failed, not enough flats, or invalid input");
            	return;
            }
        	
            
        } else {
            System.out.println("You are not eligible to apply for this project.");
            return;
        }
    }

    // Method to view available projects based on user eligibility
    public void viewAvailableProjects(List<BTOProject> projects) {
        if (projects == null || projects.isEmpty()) {
            System.out.println("No projects available.");
            return;
        }

        System.out.println("Available Projects for You:");
        for (BTOProject project : projects) {
            if (this.getAge() >= 35 && "Single".equals(this.getMaritalStatus()) && project.getType1().equals("2-Room")) {
                System.out.println("Project Name: " + project.getProjectName() + ", Location: " + project.getNeighborhood());
            } else if (this.getAge() >= 21 && "Married".equals(this.getMaritalStatus())) {
                System.out.println("Project Name: " + project.getProjectName() + ", Location: " + project.getNeighborhood());
            }
        }
    }

    // View application status
    public void viewApplicationStatus() {
    	if (this.hasAppliedForProject==true)
    	{
        System.out.println("Application status: " + this.projectStatus + ", for a " + this.typeApplied + " flat.");
        return;
    	}
    	else
    	{
    		System.out.println("You have not applied to any projects");
    		return;
    	}
    }
    
    // book flat
    public void bookFlat()
    {
    	if(this.hasAppliedForProject == false)
    	{
    		System.out.println("You have no applications.");
    		return;
    	}
    	
    	else if(this.projectStatus=="Booked")
    	{
    		System.out.println("You have already booked a flat.");
    		return;
    	}
    	else if(this.projectStatus=="Unsuccessful")
    	{
    		System.out.println("Your application is unsuccessful. Please withdraw your application and reapply");
    		return;
    	}
    	
    	else if(this.projectStatus=="Pending")
    	{
    		System.out.println("Your application is still pending approval.");
    		return;
    	}
    	
    	else if (this.projectStatus=="Successful"){
    		this.projectStatus="Booking Pending";
    		System.out.println("Your application is now Pending Booking by an officer.");
    	}
    }

    // withdraw  application
    public void withdrawApplication() {
    	if(this.hasAppliedForProject == false)
    	{
    		System.out.println("You have no applications.");
    		return;
    	}

    	else
    	{
    		this.projectStatus = "None";
            this.hasAppliedForProject = false;
            this.typeApplied = null;
            this.appliedProject = null;
    		System.out.println("Application withdrawn.");
    		this.projectStatus = "No applied projects";
    		
    		if(this.bookedProject!=null&&"2-Room".equals(this.typeBooked))
    				{
    			this.bookedProject.setNumUnitsType1(this.bookedProject.getNumUnitsType1()+1);
    				}
    		
    		if(this.bookedProject!=null&&"3-Room".equals(this.typeBooked))
			{
		this.bookedProject.setNumUnitsType2(this.bookedProject.getNumUnitsType2()+1);
			}
    		
    		this.typeBooked = null;
    		this.bookedProject = null;
    		return;
    	}
    }


    @Override
    public String toString() {
        return "Applicant{name='" + getName() + "', nric='" + getNric() + "', age=" + getAge() + 
               ", maritalStatus='" + getMaritalStatus() + "', projectStatus='" + projectStatus + "'}";
    }
    
    @Override
    public void viewProfile() {
        System.out.println("Applicant Profile:");
        System.out.println("Name: " + this.name);
        System.out.println("NRIC: " + this.nric);
        System.out.println("Age: " + this.age);
        System.out.println("Marital Status: " + this.maritalStatus);
        if(this.getTypeBooked()!=null)
        {
        	System.out.println("Flat Type Booked: " + this.getTypeBooked());
        }
        if(this.bookedProject!=null)
        {
        	System.out.println("Project Details: " + this.bookedProject.getProjectName());
        }
    }
    
}
