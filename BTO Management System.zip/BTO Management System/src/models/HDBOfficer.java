package models;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class HDBOfficer extends Applicant {
    public  List<BTOProject> projectsAssigned;
    

    // Constructor (name, nric, age, marital status, password)
    
    public HDBOfficer(String name, String nric, int age, String maritalStatus, String password) {
        super(name, nric, age, maritalStatus, password);  // Call the constructor of User
        this.projectsAssigned = new ArrayList<>();  // Default project assignment when officer is created
    }
    

    // Getter and Setter for projectAssigned
    public List<BTOProject> getProjectsAssigned() {
        return projectsAssigned;
    }
    public void setProjectsAssigned(List<BTOProject> projectsAssigned) {
        this.projectsAssigned = projectsAssigned;
    }

 // Method to add a project
    public void addProject(BTOProject project) {
        projectsAssigned.add(project);
    }

    // Method to view assigned project
    public void viewAssignedProjects() {
        if (projectsAssigned.isEmpty()) {
            System.out.println("No projects assigned.");
        } else {
            System.out.println("Assigned Projects:");
            for (BTOProject project : projectsAssigned) {
                System.out.println("Project Name: " + project.getProjectName() + ", Location: " + project.getNeighborhood());
            }
        }
        }

    // Method to change officer's password
    public void changePassword(String newPassword) {
        this.setPassword(newPassword);
        System.out.println("Password for " + this.getName() + " changed successfully!");
    }

    @Override
    public String toString() {
        return "HDBOfficer{name='" + getName() + "', nric='" + getNric() + "', age=" + getAge() + ", maritalStatus='" + getMaritalStatus() + "''}";
    }
    
    //apply to be officer of project
    public boolean officerApply(BTOProject project) {
        // Check if the officer is already assigned to this project
        if (isAssignedToProject(project)) {
            System.out.println("You are already an officer of this project.");
            return false;  // Cannot apply to a project they are already assigned to
        } 
        if (this.appliedProject==project)
        {
        	System.out.println("You have a application for this project.");
            return false; //Cannot become officer if already applied to it
        }
        
        if (hasDateClash(project))
        {
        	System.out.println("This project clashes with the date for another project you are officer of.");
        	return false;
        }
        
        if (isOfficerAssignedToProject(this, project))
        {
        	System.out.println("You are already assigned to this project.");
        	return false;
        }
        
        if (project.officerCount>=project.getOfficerSlot())
        {
        	System.out.println("All officer slots are full.");
        	return false;
        }
        
        else {
            this.projectsAssigned.add(project);  // Assign the project to the officer
            project.officerCount+=1;
            System.out.println("You have successfully applied to be the officer of the project: " + project.getProjectName());
            return true;  // Successful assignment
        }
    }
    
    public boolean isOfficerAssignedToProject(HDBOfficer officer, BTOProject project) {
        // Iterate through all the projects assigned to the officer
    	
        for (int i=0 ; i<project.officerCount; i++) {
            if (project.getOfficer().contains(officer.getName())) {
                return true;  // Officer's name matches the project name
            }
        }
        return false;  // Officer's name does not match any project name
    }
    
    public boolean hasDateClash(BTOProject newProject) {
    	/*
        LocalDate newOpeningDate = newProject.getOpeningDate();
        LocalDate newClosingDate = newProject.getClosingDate();

        for (BTOProject existingProject : projectsAssigned) {
            LocalDate existingOpeningDate = existingProject.getOpeningDate();
            LocalDate existingClosingDate = existingProject.getClosingDate();

            // Check if the new project dates overlap with any existing project
            if ((newOpeningDate.isBefore(existingClosingDate) || newOpeningDate.isEqual(existingClosingDate)) &&
                (newClosingDate.isAfter(existingOpeningDate) || newClosingDate.isEqual(existingOpeningDate))) {
                return true;  // There is a clash
            }
        }
			*/
        return false;  // No clash
    }

    // Helper method to check if the officer is already assigned to the project
    private boolean isAssignedToProject(BTOProject project) {
        for (BTOProject assignedProject : projectsAssigned) {
            if (assignedProject.equals(project)) {
                return true;  // Officer is already assigned to this project
            }
        }
        return false;  // Officer is not assigned to the project
    }
    
    @Override
    public void viewProfile() {
        System.out.println("HDB Officer Profile:");
        System.out.println("Name: " + this.name);
        System.out.println("NRIC: " + this.nric);
        System.out.println("Age: " + this.age);
        System.out.println("Marital Status: " + this.maritalStatus);
        this.viewAssignedProjects();
        
    }
    
    public void officerViewProject() {
        if (projectsAssigned.isEmpty()) {
            System.out.println("You are not assigned to any projects yet.");
        } else {
            System.out.println("You are assigned to the following projects:");
            for (BTOProject project : projectsAssigned) {
                System.out.println("Project Name: " + project.getProjectName());
                System.out.println("Project Neighborhood: " + project.getNeighborhood());
                System.out.println("Project Type1: " + project.getType1());
                System.out.println("Project Type1 Number of Units: " + project.getNumUnitsType1());
                System.out.println("Project Type1 Price: " + project.getPriceType1());
                System.out.println("Project Type2: " + project.getType2());
                System.out.println("Project Type1 Number of Units: " + project.getNumUnitsType2());
                System.out.println("Project Type2 Price: " + project.getPriceType2());
                System.out.println("Project Opening Date: " + project.getOpeningDate());
                System.out.println("Project Closing Date: " + project.getClosingDate());
                System.out.println("Project Manager: " + project.getManager());
                System.out.println("Project Opening Date: " + project.getOpeningDate());
                System.out.println("Project Officer Slot(s): " + project.getOfficerSlot());
                System.out.println("Project Officer(s): " + project.getOfficer());
            }
        }
    }
    
    public void generateReceipt(List<Applicant> applicants) {
        // Show the list of applicants
        System.out.println("List of Applicants:");
        for (int i = 0; i < applicants.size(); i++) {
            System.out.println((i + 1) + ". " + applicants.get(i).getName() + " (NRIC: " + applicants.get(i).getNric() + ")");
        }

        // Prompt the officer to choose an applicant
        System.out.println("Enter the number of the applicant you want to generate a receipt for:");
        int choice = scanner.nextInt();
        scanner.nextLine();  // consume newline character

        if (choice < 1 || choice > applicants.size()) {
            System.out.println("Invalid choice. Please try again.");
        } else {
            Applicant applicant = applicants.get(choice - 1);  // Get the selected applicant

            // Generate a receipt for the selected applicant
            System.out.println("Receipt for Applicant: " + applicant.getName());
            System.out.println("------------------------------------------------");
            System.out.println("Applicant Name: " + applicant.getName());
            System.out.println("NRIC: " + applicant.getNric());
            System.out.println("Age: " + applicant.getAge());
            System.out.println("Marital Status: " + applicant.getMaritalStatus());
            if(applicant.getTypeBooked()!=null)
            {
            	System.out.println("Flat Type Booked: " + applicant.getTypeBooked());
            }
            if(applicant.bookedProject!=null)
            {
            	System.out.println("Project Details: " + applicant.bookedProject.getProjectName());
            }
            


            System.out.println("------------------------------------------------");
        }
    }
    
    public void changeApplicationStatus(List<Applicant> applicants, List<HDBOfficer> officers) {
    	 for (Applicant applicant : applicants) {
    	        // Check if the applicant's status is "pending"
    	        if (applicant.getProjectStatus().equals("Pending")) {
    	            applicant.setProjectStatus("Successful");   	            
    	            
    	            
    	            
    	            System.out.println("Application status for " + applicant.getName() + " updated to 'Succesful'.");
    	        }
    	        
    	        if (applicant.getProjectStatus().equals("Booking Pending")) {
    	            applicant.setProjectStatus("Booked");
    	            
    	            if(applicant.getTypeApplied().equals("3-Room"))
    	            {
    	            	applicant.appliedProject.setNumUnitsType2(applicant.appliedProject.getNumUnitsType2()-1);
    	            	applicant.setTypeBooked("3-Room");
    	            	applicant.bookedProject = applicant.appliedProject;
    	            	System.out.println("Number of 3-Room flats remaining: " + applicant.appliedProject.getNumUnitsType2());
    	            }
    	            
    	            if(applicant.getTypeApplied().equals("2-Room"))
    	            {
    	            	applicant.appliedProject.setNumUnitsType1(applicant.appliedProject.getNumUnitsType1()-1);
    	            	applicant.setTypeBooked("2-Room");
    	            	applicant.bookedProject = applicant.appliedProject;
    	            	System.out.println("Number of 2-Room flats remaining: " + applicant.appliedProject.getNumUnitsType1());
    	            
    	            System.out.println("Application status for " + applicant.getNric() + " updated to 'Booked'.");
    	            
    	            
    	            }
    	        }
    	    }
    	 
    	 for (HDBOfficer officer : officers) {
 	        // Check if the applicant's status is "pending"
 	        if (officer.getProjectStatus().equals("Pending")) {
 	        	officer.setProjectStatus("Successful");   	            
 	            
 	            
 	            
 	            System.out.println("Application status for " + officer.getName() + " updated to 'Succesful'.");
 	        }
 	        
 	        if (officer.getProjectStatus().equals("Booking Pending")) {
 	        	officer.setProjectStatus("Booked");
 	            
 	            if(officer.getTypeApplied().equals("3-Room"))
 	            {
 	            	officer.appliedProject.setNumUnitsType2(officer.appliedProject.getNumUnitsType2()-1);
 	            	officer.setTypeBooked("3-Room");
 	            	officer.bookedProject = officer.appliedProject;
 	            	System.out.println("Number of 3-Room flats remaining: " + officer.appliedProject.getNumUnitsType2());
 	            }
 	            
 	            if(officer.getTypeApplied().equals("2-Room"))
 	            {
 	            	officer.appliedProject.setNumUnitsType1(officer.appliedProject.getNumUnitsType1()-1);
 	            	officer.setTypeBooked("2-Room");
 	            	officer.bookedProject = officer.appliedProject;
 	            	System.out.println("Number of 2-Room flats remaining: " + officer.appliedProject.getNumUnitsType1());
 	            
 	            System.out.println("Application status for " + officer.getNric() + " updated to 'Booked'.");
 	            
 	            
 	            }
 	        }
 	    }
    	 
    }
    
}
