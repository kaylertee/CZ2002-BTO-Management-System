package models;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class BTOProject {

    private String projectName;
    private String neighborhood;
    private String type1;
    private int numUnitsType1;
    private double priceType1;
    private String type2;
    private int numUnitsType2;
    private double priceType2;
    private String openingDate;
    private String closingDate;
    private String manager;
    private int officerSlot;
    private String officer;
    public int officerCount;

    // Constructor with all the fields
    public BTOProject(String projectName, String neighborhood, String type1, int numUnitsType1, double priceType1,
                      String type2, int numUnitsType2, double priceType2, String openingDate, String closingDate,
                      String manager, int officerSlot, String officer) {
        this.projectName = projectName;
        this.neighborhood = neighborhood;
        this.type1 = type1;
        this.numUnitsType1 = numUnitsType1;
        this.priceType1 = priceType1;
        this.type2 = type2;
        this.numUnitsType2 = numUnitsType2;
        this.priceType2 = priceType2;
        this.openingDate = openingDate;
        this.closingDate = closingDate;
        this.manager = manager;
        this.officerSlot = officerSlot;
        this.officer = officer;
        String[] words = this.officer.split(",");
        this.officerCount = words.length;
    }
    
    //Get & Set()
    
    /*
    public LocalDate getOpeningDate() {
       return LocalDate.parse(openingDate, DateTimeFormatter.ISO_LOCAL_DATE);
   
    }

    public LocalDate getClosingDate() {
        return LocalDate.parse(closingDate, DateTimeFormatter.ISO_LOCAL_DATE);
    }
	*/
    
    public String getOpeningDate() {
    	return openingDate;
    }
    
    public String getClosingDate() {
    	return closingDate;
    }
    
    
    public String getProjectName() {
        return projectName;
    }

    public String getNeighborhood() {
        return neighborhood;
    }

    public String getType1() {
        return type1;
    }

    public int getNumUnitsType1() {
        return numUnitsType1;
    }

    public double getPriceType1() {
        return priceType1;
    }

    public String getType2() {
        return type2;
    }

    public int getNumUnitsType2() {
        return numUnitsType2;
    }

    public double getPriceType2() {
        return priceType2;
    }


    public String getManager() {
        return manager;
    }

    public int getOfficerSlot() {
        return officerSlot;
    }

    public String getOfficer() {
        return officer;
    }
    
    public void setNumUnitsType1(int val) {
        this.numUnitsType1 = val;
    }
    
    public void setNumUnitsType2(int val) {
        this.numUnitsType2 = val;
    }
}
